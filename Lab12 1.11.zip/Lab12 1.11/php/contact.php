<?php
require 'D:\Programy\xampp\htdocs\Lab11 1.10\utils\PHPMailer-master\src\Exception.php';
require 'D:\Programy\xampp\htdocs\Lab11 1.10\utils\PHPMailer-master\src\PHPMailer.php';
require 'D:\Programy\xampp\htdocs\Lab11 1.10\utils\PHPMailer-master\src\SMTP.php';

use PHPMailer\PHPMailer\PHPMailer; // wysylanie e-maili przy uzyciu protokołu SMTP
use PHPMailer\PHPMailer\Exception; // wyłapuje błędy związane z wysłaniem e-maila
/*
 * Funkcja wyświetlająca formularz kontaktowy
 */
function PokazKontakt() {
    // Wyświetlanie formularza HTML do wysyłania wiadomości
    echo '<form method="POST" action="" style="max-width: 500px; margin: auto;">
            <h2>Formularz kontaktowy</h2>
            <div style="margin-bottom: 15px;">
                <label for="temat" style="display: block; font-weight: bold;">Temat:</label>
                <input type="text" name="temat" id="temat" required 
                       style="width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label for="tresc" style="display: block; font-weight: bold;">Treść wiadomości:</label>
                <textarea name="tresc" id="tresc" rows="6" required
                          style="width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px;"></textarea>
            </div>
            <div style="margin-bottom: 15px;">
                <label for="email" style="display: block; font-weight: bold;">Twój e-mail:</label>
                <input type="email" name="email" id="email" required 
                       style="width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <!-- Ukryte pole identyfikujące formularz kontaktowy -->
            <input type="hidden" name="form_type" value="contact_form">
            <button type="submit" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
                Wyślij wiadomość
            </button>
          </form>';
}

/*
 * Funkcja wysyłająca e-mail
 */
function WyslijMailKontakt($odbiorca, $temat, $wiadomosc, $nadawca)
{
    $mail = new PHPMailer(true);

    try {
        // Konfiguracja SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.wp.pl';  // Adres serwera SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'januszgalski1993@wp.pl'; // Użyj właściwego loginu
        $mail->Password = 'cottonenjoyer123!';    // Użyj właściwego hasła
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Nadawca i odbiorca
        $mail->setFrom($nadawca, 'Formularz kontaktowy');
        $mail->addAddress($odbiorca);

        // Treść wiadomości
        $mail->isHTML(false);
        $mail->Subject = $temat;
        $mail->Body = $wiadomosc;

        // Wysyłanie e-maila
        $mail->send();
        echo '[wiadomosc_wyslana]';
    } catch (Exception $e) {
        echo '[blad_wysylania_wiadomosci] ' . $mail->ErrorInfo;
    }
}


/*
 * Funkcja do przypomnienia hasła
 */
function PrzypomnijHaslo($email, $nowe_haslo) {
    // Przygotowanie tematu i treści wiadomości z przypomnieniem hasła
    $temat = 'Przypomnienie hasła';
    $wiadomosc = "Twoje nowe hasło do panelu admina to: " . htmlspecialchars($nowe_haslo, ENT_QUOTES, 'UTF-8');
    $nadawca = 'no-reply@mojastrona.pl';

    // Wywołanie funkcji do wysyłania e-maila
    WyslijMailKontakt($email, $temat, $wiadomosc, $nadawca);
}

/*
 * Obsługa formularza kontaktowego
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'contact_form') {
    // Filtrowanie i walidacja danych wejściowych z formularza
    $temat = filter_input(INPUT_POST, 'temat', FILTER_SANITIZE_STRING);
    $tresc = filter_input(INPUT_POST, 'tresc', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

    if ($temat && $tresc && $email) {
        $odbiorca = '169349@student.uwm.edu.pl'; // Adres e-mail odbiorcy wiadomości

        // Wywołanie funkcji do wysyłania wiadomości
        WyslijMailKontakt($odbiorca, $temat, $tresc, $email);
    } else {
        // Informacja o brakujących danych w formularzu lub błędnych danych
        echo '<p style="color: red;">Nie wypełniłeś wszystkich pól poprawnie.</p>';
    }
}
?>
