<?php
include('cfg.php'); // Połączenie z bazą danych

// Dodawanie produktu do koszyka
function DodajDoKoszyka($productId, $quantity) {
    global $link;

    // Pobranie danych produktu z bazy danych
    $stmt = $link->prepare("SELECT id, tytul, cena_netto, podatek_vat, ilosc_magazyn, status_dostepnosci FROM produkty WHERE id = ?");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();

        // Sprawdzenie, czy w magazynie jest wystarczająca ilość produktów
        if ($product['ilosc_magazyn'] >= $quantity && $product['status_dostepnosci'] != 'niedostępny') {
            $price_brutto = number_format($product['cena_netto'] * (1 + (0.01 * $product['podatek_vat'])), 2, '.', '');

            // Dodanie do sesji (koszyka)
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }

            $_SESSION['cart'][] = [
                'id' => $product['id'],
                'tytul' => $product['tytul'],
                'quantity' => $quantity,
                'price_netto' => $product['cena_netto'],
                'price_brutto' => $price_brutto,
            ];

            // Zmniejszenie ilości w magazynie o ilość dodaną do koszyka
            $newQuantity = $product['ilosc_magazyn'] - $quantity;
            $updateStmt = $link->prepare("UPDATE produkty SET ilosc_magazyn = ? WHERE id = ?");
            $updateStmt->bind_param("ii", $newQuantity, $productId);
            $updateStmt->execute();
            $updateStmt->close();

        }
    } 

    $stmt->close();
}

// Usunięcie produktu z koszyka
function UsunZKoszyka($productId) {
    global $link;

    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $key => $item) {
            if ($item['id'] == $productId) {
                // 1. Zwiększenie ilości towaru w magazynie na podstawie danych z koszyka
                $newIlosc = $item['quantity'];  // Ilość towaru, która była w koszyku

                // 2. Zaktualizowanie ilości towaru w bazie danych
                $stmt = $link->prepare("UPDATE produkty SET ilosc_magazyn = ilosc_magazyn + ? WHERE id = ?");
                $stmt->bind_param("ii", $newIlosc, $productId);
                $stmt->execute();
                $stmt->close();

                // 3. Usunięcie produktu z koszyka
                unset($_SESSION['cart'][$key]);
                break;
            }
        }
        $_SESSION['cart'] = array_values($_SESSION['cart']); // Resetuje indeksy po usunięciu
    }
}



// Wyświetlenie zawartości koszyka
function PokazKoszyk() {
    if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
        echo "<h2 align=center>Twój koszyk:</h2>
                <table border='1'>
                <tr>
                    <th>ID produktu</th>
                    <th>Tytuł</th>
                    <th>Ilość</th>
                    <th>Cena netto</th>
                    <th>Cena brutto</th>
                </tr>";
        foreach ($_SESSION['cart'] as $item) {
            echo "<tr>
                    <td>{$item['id']}</td>
                    <td>{$item['tytul']}</td>
                    <td>{$item['quantity']}</td>
                    <td>{$item['price_netto']}</td>
                    <td>{$item['price_brutto']}</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "<h2>Koszyk jest pusty.</h2>";
    }
}

// Obliczenie całkowitej wartości koszyka
function PodsumujKoszyk() {
    $total = 0;
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $total += $item['price_brutto'] * $item['quantity'];
        }
    }
    return number_format($total, 2, '.', '');
}

// Wyświetlenie formularzy i koszyka
function wyswietl() {
    echo '<h1>Koszyk i Produkty</h1>';
    
    // Wyświetlenie zawartości koszyka
    PokazKoszyk();

        echo '
        <!-- Formularz dodawania do koszyka -->
        <form method="POST">
            <h3>Dodaj produkt do koszyka</h3>
            <label>ID produktu: <input type="number" name="product_id" required></label><br>
            <label>Ilość: <input type="number" name="quantity" min="1" required></label><br>
            <input type="hidden" name="action" value="add">
            <button type="submit">Dodaj do koszyka</button>
        </form>

        <!-- Formularz usuwania z koszyka -->
        <form method="POST">
            <h3>Usuń produkt z koszyka</h3>
            <label>ID produktu: <input type="number" name="product_id" required></label><br>
            <input type="hidden" name="action" value="remove">
            <button type="submit">Usuń z koszyka</button>
        </form>
    ';
    
    // Wyświetlenie całkowitej wartości koszyka
    echo '<h2 align=right>Całkowita wartość koszyka: ' . PodsumujKoszyk() . ' zł</h2>';

    echo '
    <h2>Produkty w bazie danych</h2>
    ';
    PokazProdukty(); // Wyświetlenie produktów z bazy danych

}

// Obsługa akcji
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        $productId = $_POST['product_id'];
        $quantity = $_POST['quantity'] ?? 1;

        if ($action === 'add') {
            DodajDoKoszyka($productId, $quantity);
        } elseif ($action === 'remove') {
            UsunZKoszyka($productId);
        }
    }
}

?>
