<?php
include('cfg.php'); // Połączenie z bazą danych

// Dodawanie produktu do koszyka
function DodajDoKoszyka($produktId, $ilosc) {
    global $link;

    // Pobranie danych produktu z bazy danych
    $stmt = $link->prepare("SELECT id, tytul, cena_netto, podatek_vat, ilosc_magazyn, status_dostepnosci FROM produkty WHERE id = ?");
    $stmt->bind_param("i", $produktId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $produkt = $result->fetch_assoc();

        // Sprawdzenie, czy w magazynie jest wystarczająca ilość produktów
        if ($produkt['ilosc_magazyn'] >= $ilosc && $produkt['status_dostepnosci'] != 'niedostępny') {
            $cenaBrutto = number_format($produkt['cena_netto'] * (1 + (0.01 * $produkt['podatek_vat'])), 2, '.', '');

            // Dodanie do sesji (koszyka)
            if (!isset($_SESSION['koszyk'])) {
                $_SESSION['koszyk'] = [];
            }

            $_SESSION['koszyk'][] = [
                'id' => $produkt['id'],
                'tytul' => $produkt['tytul'],
                'ilosc' => $ilosc,
                'cena_netto' => $produkt['cena_netto'],
                'cena_brutto' => $cenaBrutto,
            ];

            // Zmniejszenie ilości w magazynie o ilość dodaną do koszyka
            $nowaIlosc = $produkt['ilosc_magazyn'] - $ilosc;
            $updateStmt = $link->prepare("UPDATE produkty SET ilosc_magazyn = ? WHERE id = ?");
            $updateStmt->bind_param("ii", $nowaIlosc, $produktId);
            $updateStmt->execute();
            $updateStmt->close();

        }
    } 

    $stmt->close();
}

// Usunięcie produktu z koszyka
function UsunZKoszyka($produktId) {
    global $link;

    if (isset($_SESSION['koszyk'])) {
        foreach ($_SESSION['koszyk'] as $key => $item) {
            if ($item['id'] == $produktId) {
                // Zwiększenie ilości towaru w magazynie na podstawie danych z koszyka
                $nowaIlosc = $item['ilosc'];  // Ilość towaru, która była w koszyku

                // Zaktualizowanie ilości towaru w bazie danych
                $stmt = $link->prepare("UPDATE produkty SET ilosc_magazyn = ilosc_magazyn + ? WHERE id = ?");
                $stmt->bind_param("ii", $nowaIlosc, $produktId);
                $stmt->execute();
                $stmt->close();

                // Usunięcie produktu z koszyka
                unset($_SESSION['koszyk'][$key]);
                break;
            }
        }
        $_SESSION['koszyk'] = array_values($_SESSION['koszyk']); // Resetuje indeksy po usunięciu
    }
}

// Wyświetlenie zawartości koszyka
function PokazKoszyk() {
    if (isset($_SESSION['koszyk']) && count($_SESSION['koszyk']) > 0) {
        echo "<h2 align=center>Twój koszyk:</h2>
                <table border='1'>
                <tr>
                    <th>ID produktu</th>
                    <th>Tytuł</th>
                    <th>Ilość</th>
                    <th>Cena netto</th>
                    <th>Cena brutto</th>
                </tr>";
        foreach ($_SESSION['koszyk'] as $item) {
            echo "<tr>
                    <td>{$item['id']}</td>
                    <td>{$item['tytul']}</td>
                    <td>{$item['ilosc']}</td>
                    <td>{$item['cena_netto']}</td>
                    <td>{$item['cena_brutto']}</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "<h2>Koszyk jest pusty.</h2>";
    }
}

// Obliczenie całkowitej wartości koszyka
function PodsumujKoszyk() {
    $total = 0;
    if (isset($_SESSION['koszyk'])) {
        foreach ($_SESSION['koszyk'] as $item) {
            $total += $item['cena_brutto'] * $item['ilosc'];
        }
    }
    return number_format($total, 2, '.', '');
}

// Wyświetlenie formularzy i koszyka
function wyswietl() {
    echo '<h1>Koszyk i Produkty</h1>';
    
    // Wyświetlenie zawartości koszyka
    PokazKoszyk();

    echo '
    <!-- Formularz dodawania do koszyka -->
    <form method="POST">
        <h3>Dodaj produkt do koszyka</h3>
        <label>ID produktu: <input type="number" name="product_id" required></label><br>
        <label>Ilość: <input type="number" name="quantity" min="1" required></label><br>
        <input type="hidden" name="action" value="add">
        <button type="submit">Dodaj do koszyka</button>
    </form>

    <!-- Formularz usuwania z koszyka -->
    <form method="POST">
        <h3>Usuń produkt z koszyka</h3>
        <label>ID produktu: <input type="number" name="product_id" required></label><br>
        <input type="hidden" name="action" value="remove">
        <button type="submit">Usuń z koszyka</button>
    </form>
';

    // Wyświetlenie całkowitej wartości koszyka
    echo '<h2 align=right>Całkowita wartość koszyka: ' . PodsumujKoszyk() . ' zł</h2>';

    echo '
    <h2>Produkty w bazie danych</h2>
    ';
    pokazProdukty(); // Wyświetlenie produktów z bazy danych
}

// Obsługa akcji
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        $produktId = $_POST['product_id'];
        $ilosc = $_POST['quantity'] ?? 1;

        if ($action === 'add') {
            DodajDoKoszyka($produktId, $ilosc);
        } elseif ($action === 'remove') {
            UsunZKoszyka($produktId);
        }
    }
}

?>
