<?php
// Funkcja wyświetlająca formularz kontaktowy
function PokazKontakt() {
    return '
        <h2>Formularz kontaktowy</h2>
        <form action="" method="post">
            <input type="hidden" name="akcja" value="kontakt">
            <label for="email">Twój email:</label>
            <input type="email" name="email" id="email" required><br>

            <label for="temat">Temat:</label>
            <input type="text" name="temat" id="temat" required><br>

            <label for="tresc">Treść wiadomości:</label><br>
            <textarea name="tresc" id="tresc" rows="4" required></textarea><br>

            <input type="submit" name="wyslij" value="Wyślij wiadomość">
        </form>

        <h2>Przypomnienie hasła</h2>
        <form action="" method="post">
            <input type="hidden" name="akcja" value="przypomnienie">
            <label for="email">Podaj swój email:</label>
            <input type="email" name="email" id="email" required><br>

            <input type="submit" name="przypomnienie" value="Przypomnij hasło">
        </form>
    ';
}

// Funkcja wysyłająca maila
function WyslijMailKontakt($odbiorca) {
    if (empty($_POST['temat']) || empty($_POST['tresc']) || empty($_POST['email'])) {
        echo '[nie_wypelniles_pola]';
    } else {
        $mail['subject'] = $_POST['temat'];
        $mail['body'] = $_POST['tresc'];
        $mail['sender'] = $_POST['email'];
        $mail['reciptient'] = $odbiorca; 

        $header = "From: Formularz kontaktowy <".$mail['sender'].">\n";
        $header .= "MIME-Version: 1.0\nContent-Type: text/plain; charset=utf-8\nContent-Transfer-Encoding: 8bit\n";
        $header .= "X-Sender: <".$mail['sender'].">\n";
        $header .= "X-Mailer: PRapwww main 1.2\n";
        $header .= "X-Priority: 3\n";
        $header .= "Return-Path: <".$mail['sender'].">\n";

        // Wysłanie wiadomości
        if(mail($mail['reciptient'], $mail['subject'], $mail['body'], $header)) {
            echo '[wiadomosc_wyslana]';
        } else {
            echo '[blad_wysylania]';
        }
    }
}

//  Funkcja przypominająca hasło
function PrzypomnijHaslo() {
    if (!empty($_POST['email'])) {
        $email = $_POST['email'];
        $haslo = 'sernik123'; // Stałe hasło - w przyszłości zastąpić pobieraniem z bazy danych.

        // Przygotowanie tematu i treści wiadomości
        $_POST['temat'] = "Przypomnienie hasła do panelu admina";
        $_POST['tresc'] = "Cześć, Twoje hasło do panelu admina to: " . $haslo . "\n\nProszę zachować je w bezpiecznym miejscu.";

        // Wywołanie funkcji wysyłającej wiadomość
        WyslijMailKontakt($email);

        // Informacja zwrotna dla użytkownika
        echo "Link przypomnienia hasła został wysłany na Twój adres e-mail.";
    } else {
        echo "Proszę podać adres e-mail.";
    }
}



?>
