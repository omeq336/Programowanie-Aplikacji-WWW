<?php
/*
 * Funkcja wyświetlająca zawartość podstrony
 */
function pokazPodstrone($id) {
    global $link; // Użycie globalnego połączenia z bazą danych

    // Sprawdzenie i walidacja ID
    $id_clear = filter_var($id, FILTER_VALIDATE_INT); 
    if ($id_clear === false) {
        return '[nieprawidłowe_id]'; 
    }

    // Przygotowanie zapytania SQL (prepared statement) które pomaga zapobiec sql injection
    $query = "SELECT page_content FROM page_list WHERE id = ? LIMIT 1"; // Uzywamy ? w celu powiązania z mysqli_prepare
    $stmt = mysqli_prepare($link, $query); // zapytanie przygotowane, zabezpieczające przed sql injection

    if ($stmt) { // sprawdzamy czy zapytanie zostalo prawidlowo przygotowane
        // Przypisanie parametru do zapytania
        mysqli_stmt_bind_param($stmt, 'i', $id_clear); // podajemy 'i' bo chcemy przekazac integer, $id_clear to przekazywana wartosc

        // Wykonanie zapytania
        mysqli_stmt_execute($stmt);

        // Pobranie wyniku zapytania
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);

        // Sprawdzenie, czy rekord został znaleziony
        if ($row) { // sprawdzamy czy $row zawiera dane
            return $row['page_content']; 
        } else {
            return '[nie_znaleziono_strony]'; // Komunikat, jeśli nie ma podstrony o podanym ID
        }


        // Zamknięcie zapytania
        mysqli_stmt_close($stmt);
    } else {
        return '[błąd_zapytania]'; // Komunikat w przypadku błędu przygotowania zapytania
    }
}
?>