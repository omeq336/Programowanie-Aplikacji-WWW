<?php
// Funkcja wyświetlająca formularz kontaktowy
function PokazKontakt() {
    return '
        <form action="" method="post">
            <label for="email">Twój email:</label>
            <input type="email" name="email" id="email" required><br>

            <label for="temat">Temat:</label>
            <input type="text" name="temat" id="temat" required><br>

            <label for="tresc">Treść wiadomości:</label><br>
            <textarea name="tresc" id="tresc" rows="4" required></textarea><br>

            <input type="submit" name="wyslij" value="Wyślij wiadomość">
        </form>
    ';
}

// Funkcja wysyłająca maila
function WyslijMailKontakt($odbiorca) {
    if (empty($_POST['temat']) || empty($_POST['tresc']) || empty($_POST['email'])) {
        echo '[nie_wypelniles_pola]';
    } else {
        $mail['subject'] = $_POST['temat'];
        $mail['body'] = $_POST['tresc'];
        $mail['sender'] = $_POST['email'];
        $mail['reciptient'] = $odbiorca; 

        $header = "From: Formularz kontaktowy <".$mail['sender'].">\n";
        $header .= "MIME-Version: 1.0\nContent-Type: text/plain; charset=utf-8\nContent-Transfer-Encoding: 8bit\n";
        $header .= "X-Sender: <".$mail['sender'].">\n";
        $header .= "X-Mailer: PRapwww main 1.2\n";
        $header .= "X-Priority: 3\n";
        $header .= "Return-Path: <".$mail['sender'].">\n";

        // Wysłanie wiadomości
        if(mail($mail['reciptient'], $mail['subject'], $mail['body'], $header)) {
            echo '[wiadomosc_wyslana]';
        } else {
            echo '[blad_wysylania]';
        }
    }
}

//  Funkcja przypominająca hasło
function PrzypomnijHaslo() {
    if (isset($_POST['email'])) {
        // Przypuszczamy, że hasło jest wprowadzane na stałe (co nie jest bezpieczne)
        $email = $_POST['email'];
        $haslo = 'TajneHaslo123'; // Hasło do przypomnienia (powinno być pobrane z bazy danych)

        // Wysyłamy e-maila z przypomnieniem hasła
        $temat = "Przypomnienie hasła do panelu admina";
        $tresc = "Cześć,\n\nTwoje hasło do panelu admina to: " . $haslo . "\n\nProszę zachować je w bezpiecznym miejscu.";
        
        // Używamy metody WyslijMailKontakt() do wysyłki
        WyslijMailKontakt($email);  // Można dodać 'admin@firma.com' jako odbiorcę, np. do admina

        // Można też dodać komunikat o wysłaniu e-maila
        echo "Link przypomnienia hasła został wysłany na Twój adres e-mail.";
    } else {
        // Formularz do przypomnienia hasła
        echo '
            <form action="" method="post">
                <label for="email">Podaj swój email:</label>
                <input type="email" name="email" id="email" required><br>

                <input type="submit" name="przypomnienie" value="Przypomnij hasło">
            </form>
        ';
    }
}


?>
