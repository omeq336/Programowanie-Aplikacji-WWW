<?php
$nr_indeksu = '169349';
$nrGrupy = 'X';

echo 'Jan Kowalski'.$nr_indeksu.' grupa '.$nrGrupy.'<br /> <br />';
echo 'Zastosowanie metody include() <br />';

if((include 'php/includeTest.php') == TRUE){
echo 'OK';
echo " A $color $fruit";
}

echo 'Zastosowanie metody require_once() <br />';

$s = require_once('php/includeTest.php');
echo "\n" . $s;

echo '<br>Zastosowanie if, else, elseif<br />';

$a = 5;
$b = 4;
if($a+$b == 9){
	echo "True";
}else if ($a+$b == 12)
{
	echo "Wynosi to 12";
}else
{
	echo "False";
}

echo '<br>Zastosowanie switch<br />';

switch ($a){
	case 1:
	echo "To jedynka!";
	break;
	
	case 4:
	echo "To czwórka!";
	break;
	
	default:
	echo "Napewno masz jakąś cyfrę!<br>";
}

echo '<br>Zastosowanie for<br />';
for($i = 0; $i < 10; $i++){
	echo "Cyfra to: $i <br>";
}

echo '<br>Zastosowanie while<br />';
$j = 10;
while($j > 0){
	echo "Cyfra to $j <br>";
	$j -= 1;
}

?>